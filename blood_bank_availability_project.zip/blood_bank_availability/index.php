<?php
require __DIR__ . '/config.php';

$bloodGroups = ['A+','A-','B+','B-','AB+','AB-','O+','O-'];
$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

$bloodFilter = trim((string)($_GET['blood_group'] ?? ''));
$cityFilter = trim((string)($_GET['city'] ?? ''));
if (!in_array($bloodFilter, $bloodGroups, true)) $bloodFilter = '';
$cityFilter = mb_substr($cityFilter, 0, 100);

$stats = [
  'donors' => (int)$conn->query("SELECT COUNT(*) n FROM donors")->fetch_assoc()['n'],
  'available' => (int)$conn->query("SELECT COUNT(*) n FROM donors WHERE available=1")->fetch_assoc()['n'],
  'requests' => (int)$conn->query("SELECT COUNT(*) n FROM blood_requests WHERE status IN ('Pending','Contacted')")->fetch_assoc()['n'],
  'groups' => (int)$conn->query("SELECT COUNT(DISTINCT blood_group) n FROM donors WHERE available=1")->fetch_assoc()['n'],
];

$sql = "SELECT id, full_name, blood_group, phone, city, available, created_at FROM donors WHERE available=1";
$types = '';
$params = [];
if ($bloodFilter !== '') { $sql .= " AND blood_group=?"; $types .= 's'; $params[] = $bloodFilter; }
if ($cityFilter !== '') { $sql .= " AND city LIKE ?"; $types .= 's'; $params[] = '%' . $cityFilter . '%'; }
$sql .= " ORDER BY created_at DESC LIMIT 100";
$stmt = $conn->prepare($sql);
if ($types !== '') $stmt->bind_param($types, ...$params);
$stmt->execute();
$donors = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$recentRequests = $conn->query("SELECT id, requester_name, blood_group, units_needed, city, urgency, status, created_at FROM blood_requests ORDER BY created_at DESC LIMIT 5")->fetch_all(MYSQLI_ASSOC);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>LifeLink | Blood Bank Availability</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="style.css">
</head>
<body>
<header class="topbar">
  <a class="brand" href="index.php"><span class="brand-mark">♥</span><span>Life<span class="brand-red">Link</span><small> BLOOD CONNECT</small></span></a>
  <nav><a class="active" href="index.php">Dashboard</a><a href="#donors">Find Donors</a><a href="register_donor.php">Become a Donor</a><a href="request_blood.php" class="nav-cta">Request Blood <span>↗</span></a></nav>
</header>
<main>
<section class="hero">
  <div class="hero-copy">
    <span class="eyebrow"><span class="pulse"></span> EVERY DROP MAKES A DIFFERENCE</span>
    <h1>Connecting lives,<br><em>one drop at a time.</em></h1>
    <p>Find available blood donors near you or register to help someone when it matters most.</p>
    <div class="hero-actions"><a class="btn btn-light" href="#donors">Find a donor <span>→</span></a><a class="btn btn-outline" href="register_donor.php">Register as donor</a></div>
    <div class="trust-line"><span class="avatars">♥ ♥ ♥</span><span>Small act. <b>Big impact.</b></span></div>
  </div>
  <div class="hero-art" aria-hidden="true">
    <div class="orb orb-one"></div><div class="orb orb-two"></div>
    <div class="drop-card"><div class="drop-icon">♥</div><div class="drop-label">THE GIFT OF LIFE</div><div class="drop-big">Donate<br>blood. Save<br><span>lives.</span></div><div class="drop-bottom"><span class="mini-dot"></span> Be someone's hero today</div></div>
    <div class="float-note note-top"><span class="note-icon">✚</span><span><b>Every 2 seconds</b><small>someone needs blood</small></span></div>
    <div class="float-note note-bottom"><span class="note-heart">♥</span><span><b>Be the reason</b><small>someone smiles today</small></span></div>
  </div>
</section>

<?php if ($flash): ?><div class="flash <?= e($flash['type'] ?? 'success') ?>"><?= e($flash['message'] ?? '') ?></div><?php endif; ?>

<section class="stats-grid">
  <article class="stat-card"><div class="stat-icon red">♥</div><div><span class="stat-label">Registered donors</span><strong><?= number_format($stats['donors']) ?></strong><small>People ready to help</small></div><span class="stat-arrow">↗</span></article>
  <article class="stat-card"><div class="stat-icon green">✓</div><div><span class="stat-label">Available donors</span><strong><?= number_format($stats['available']) ?></strong><small>Marked available now</small></div><span class="stat-arrow">↗</span></article>
  <article class="stat-card"><div class="stat-icon orange">＋</div><div><span class="stat-label">Open requests</span><strong><?= number_format($stats['requests']) ?></strong><small>Pending or contacted</small></div><span class="stat-arrow">↗</span></article>
  <article class="stat-card"><div class="stat-icon purple">◉</div><div><span class="stat-label">Blood groups</span><strong><?= number_format($stats['groups']) ?><small class="out-of"> / 8</small></strong><small>Groups represented</small></div><span class="stat-arrow">↗</span></article>
</section>

<section class="section" id="donors">
  <div class="section-heading"><div><span class="section-kicker">FIND YOUR MATCH</span><h2>Available blood donors</h2><p>Search registered donors by blood group and city.</p></div><a class="text-link" href="register_donor.php">+ Add donor</a></div>
  <form class="search-panel" method="get" action="index.php#donors">
    <label class="field"><span>Blood group</span><select name="blood_group"><option value="">All blood groups</option><?php foreach ($bloodGroups as $group): ?><option value="<?= e($group) ?>" <?= $bloodFilter === $group ? 'selected' : '' ?>><?= e($group) ?></option><?php endforeach; ?></select></label>
    <label class="field city-field"><span>City / location</span><input name="city" value="<?= e($cityFilter) ?>" maxlength="100" placeholder="Enter city, e.g. Chennai"></label>
    <button class="btn btn-red" type="submit">⌕ &nbsp; Search donors</button>
    <?php if ($bloodFilter !== '' || $cityFilter !== ''): ?><a class="clear-link" href="index.php#donors">Clear</a><?php endif; ?>
  </form>

  <?php if (!$donors): ?>
    <div class="empty-state"><div class="empty-heart">♡</div><h3>No matching donors found</h3><p>Try another blood group or city, or register a donor to grow the network.</p><a class="btn btn-red" href="register_donor.php">Register a donor</a></div>
  <?php else: ?>
  <div class="donor-grid">
    <?php foreach ($donors as $donor): ?>
    <article class="donor-card">
      <div class="donor-top"><div class="avatar"><?= e(strtoupper(mb_substr($donor['full_name'],0,1))) ?></div><span class="available-pill"><i></i> Available</span></div>
      <h3><?= e($donor['full_name']) ?></h3><p class="donor-location">⌖ <?= e($donor['city']) ?></p>
      <div class="donor-bottom"><span class="blood-badge"><?= e($donor['blood_group']) ?></span><a class="contact-link" href="tel:<?= e($donor['phone']) ?>">Contact donor ↗</a></div>
      <p class="privacy-note">Please confirm eligibility and availability directly.</p>
    </article>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</section>

<section class="section requests-section">
  <div class="section-heading"><div><span class="section-kicker">COMMUNITY NEEDS</span><h2>Recent blood requests</h2><p>Recent requests submitted through LifeLink.</p></div><a class="text-link" href="request_blood.php">+ Create request</a></div>
  <?php if (!$recentRequests): ?>
    <div class="request-empty">No blood requests yet. If blood is needed, submit the first request.</div>
  <?php else: ?>
  <div class="table-wrap"><table><thead><tr><th>REQUEST</th><th>BLOOD GROUP</th><th>UNITS</th><th>LOCATION</th><th>URGENCY</th><th>STATUS</th></tr></thead><tbody>
  <?php foreach ($recentRequests as $r): ?><tr><td><b><?= e($r['requester_name']) ?></b><small><?= e(date('d M Y', strtotime($r['created_at']))) ?></small></td><td><span class="blood-badge small-badge"><?= e($r['blood_group']) ?></span></td><td><?= (int)$r['units_needed'] ?></td><td><?= e($r['city']) ?></td><td><span class="urgency <?= strtolower(e($r['urgency'])) ?>"><?= e($r['urgency']) ?></span></td><td><span class="status"><?= e($r['status']) ?></span></td></tr><?php endforeach; ?>
  </tbody></table></div>
  <?php endif; ?>
</section>

<section class="bottom-cta"><div class="cta-heart">♥</div><div><h2>Your one donation can mean everything.</h2><p>Join the LifeLink donor community and help someone get another tomorrow.</p></div><a class="btn btn-light" href="register_donor.php">Become a donor <span>→</span></a></section>
</main>
<footer><a class="brand footer-brand" href="index.php"><span class="brand-mark">♥</span><span>Life<span class="brand-red">Link</span><small> BLOOD CONNECT</small></span></a><p>Built to connect donors and people in need. <b>Give blood. Give hope.</b></p><span>© <?= date('Y') ?> LifeLink · Student project</span></footer>
</body></html>
