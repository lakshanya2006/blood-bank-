<?php
require __DIR__ . '/config.php';
$groups = ['A+','A-','B+','B-','AB+','AB-','O+','O-'];
$errors = [];
$name = $blood = $phone = $city = '';
$available = true;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $name = trim((string)($_POST['full_name'] ?? ''));
    $blood = (string)($_POST['blood_group'] ?? '');
    $phone = trim((string)($_POST['phone'] ?? ''));
    $city = trim((string)($_POST['city'] ?? ''));
    $available = isset($_POST['available']);
    if ($name === '' || mb_strlen($name) > 100) $errors[] = 'Enter a name (maximum 100 characters).';
    if (!in_array($blood, $groups, true)) $errors[] = 'Choose a valid blood group.';
    if (!preg_match('/^[0-9+\-\s()]{7,20}$/', $phone)) $errors[] = 'Enter a valid phone number (7–20 characters).';
    if ($city === '' || mb_strlen($city) > 100) $errors[] = 'Enter a city (maximum 100 characters).';
    if (!$errors) {
        $stmt = $conn->prepare('INSERT INTO donors (full_name,blood_group,phone,city,available) VALUES (?,?,?,?,?)');
        $availability = $available ? 1 : 0;
        $stmt->bind_param('ssssi', $name, $blood, $phone, $city, $availability);
        $stmt->execute();
        $_SESSION['flash'] = ['type'=>'success','message'=>'Donor registered successfully. Thank you for helping save lives!'];
        redirect('index.php#donors');
    }
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Become a Donor | LifeLink</title><link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@400;500;600;700;800&display=swap" rel="stylesheet"><link rel="stylesheet" href="style.css"></head><body>
<header class="topbar"><a class="brand" href="index.php"><span class="brand-mark">♥</span><span>Life<span class="brand-red">Link</span><small> BLOOD CONNECT</small></span></a><nav><a href="index.php">Dashboard</a><a href="index.php#donors">Find Donors</a><a class="active" href="register_donor.php">Become a Donor</a><a href="request_blood.php" class="nav-cta">Request Blood <span>↗</span></a></nav></header>
<main class="form-page"><div class="form-intro"><span class="section-kicker">BE SOMEONE'S HERO</span><h1>Become a <em>blood donor.</em></h1><p>Your details help people nearby find a potential donor. Register only if you consent to be contacted.</p><div class="form-tip">♥ &nbsp; Your kindness can make a life-changing difference.</div></div>
<form class="main-form" method="post" novalidate><input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>"><h2>Donor details</h2><p class="form-subtitle">Fields marked * are required.</p>
<?php if ($errors): ?><div class="flash error"><ul><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
<label class="field"><span>Full name *</span><input name="full_name" required maxlength="100" value="<?= e($name) ?>" placeholder="Enter your full name"></label>
<div class="form-row"><label class="field"><span>Blood group *</span><select name="blood_group" required><option value="">Select group</option><?php foreach($groups as $g): ?><option value="<?= e($g) ?>" <?= $blood===$g?'selected':'' ?>><?= e($g) ?></option><?php endforeach; ?></select></label><label class="field"><span>Phone number *</span><input name="phone" required maxlength="20" value="<?= e($phone) ?>" placeholder="+91 98765 43210" inputmode="tel"></label></div>
<label class="field"><span>City / location *</span><input name="city" required maxlength="100" value="<?= e($city) ?>" placeholder="e.g. Coimbatore"></label>
<label class="check-row"><input type="checkbox" name="available" value="1" <?= $available?'checked':'' ?>><span><b>I am currently available to be contacted</b><small>Untick this if you are not currently available.</small></span></label>
<button class="btn btn-red btn-wide" type="submit">Register as donor <span>→</span></button><p class="privacy-note form-privacy">Your contact details are shown to users of this demo application. Use fictional data for classroom demonstrations.</p></form></main>
<footer><a class="brand footer-brand" href="index.php"><span class="brand-mark">♥</span><span>Life<span class="brand-red">Link</span><small> BLOOD CONNECT</small></span></a><p>Give blood. Give hope.</p><span>© <?= date('Y') ?> LifeLink · Student project</span></footer></body></html>
