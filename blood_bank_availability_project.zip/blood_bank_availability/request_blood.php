<?php
require __DIR__ . '/config.php';
$groups = ['A+','A-','B+','B-','AB+','AB-','O+','O-'];
$urgencies = ['Normal','Urgent','Emergency'];
$errors = [];
$name = $blood = $phone = $city = $hospital = '';
$units = '1'; $urgency = 'Normal';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $name = trim((string)($_POST['requester_name'] ?? ''));
    $blood = (string)($_POST['blood_group'] ?? '');
    $phone = trim((string)($_POST['phone'] ?? ''));
    $city = trim((string)($_POST['city'] ?? ''));
    $hospital = trim((string)($_POST['hospital'] ?? ''));
    $units = (string)($_POST['units_needed'] ?? '1');
    $urgency = (string)($_POST['urgency'] ?? 'Normal');
    if ($name === '' || mb_strlen($name)>100) $errors[] = 'Enter the requester name.';
    if (!in_array($blood,$groups,true)) $errors[] = 'Choose a valid blood group.';
    if (!ctype_digit($units) || (int)$units<1 || (int)$units>20) $errors[] = 'Units needed must be between 1 and 20.';
    if (!preg_match('/^[0-9+\-\s()]{7,20}$/',$phone)) $errors[] = 'Enter a valid phone number.';
    if ($city === '' || mb_strlen($city)>100) $errors[] = 'Enter a city.';
    if ($hospital === '' || mb_strlen($hospital)>150) $errors[] = 'Enter a hospital or medical facility name.';
    if (!in_array($urgency,$urgencies,true)) $errors[] = 'Choose a valid urgency.';
    if (!$errors) {
        $unitsInt=(int)$units;
        $stmt=$conn->prepare('INSERT INTO blood_requests (requester_name,blood_group,units_needed,city,phone,hospital,urgency) VALUES (?,?,?,?,?,?,?)');
        $stmt->bind_param('ssissss',$name,$blood,$unitsInt,$city,$phone,$hospital,$urgency);
        $stmt->execute();
        $_SESSION['flash']=['type'=>'success','message'=>'Blood request submitted. Please contact the hospital/blood bank directly for urgent needs.'];
        redirect('index.php');
    }
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Request Blood | LifeLink</title><link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@400;500;600;700;800&display=swap" rel="stylesheet"><link rel="stylesheet" href="style.css"></head><body>
<header class="topbar"><a class="brand" href="index.php"><span class="brand-mark">♥</span><span>Life<span class="brand-red">Link</span><small> BLOOD CONNECT</small></span></a><nav><a href="index.php">Dashboard</a><a href="index.php#donors">Find Donors</a><a href="register_donor.php">Become a Donor</a><a class="nav-cta active" href="request_blood.php">Request Blood <span>↗</span></a></nav></header>
<main class="form-page"><div class="form-intro"><span class="section-kicker">REQUEST SUPPORT</span><h1>Find a blood <em>match.</em></h1><p>Submit the required blood group and location so your request is recorded in the system.</p><div class="form-tip">✚ &nbsp; In an emergency, contact a hospital or licensed blood bank immediately.</div></div>
<form class="main-form" method="post" novalidate><input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>"><h2>Blood request details</h2><p class="form-subtitle">Fields marked * are required.</p>
<?php if ($errors): ?><div class="flash error"><ul><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
<label class="field"><span>Requester / patient contact name *</span><input name="requester_name" required maxlength="100" value="<?= e($name) ?>" placeholder="Enter name"></label>
<div class="form-row"><label class="field"><span>Blood group *</span><select name="blood_group" required><option value="">Select group</option><?php foreach($groups as $g): ?><option value="<?= e($g) ?>" <?= $blood===$g?'selected':'' ?>><?= e($g) ?></option><?php endforeach; ?></select></label><label class="field"><span>Units needed (1–20) *</span><input type="number" name="units_needed" min="1" max="20" required value="<?= e($units) ?>"></label></div>
<div class="form-row"><label class="field"><span>Phone number *</span><input name="phone" required maxlength="20" value="<?= e($phone) ?>" inputmode="tel" placeholder="+91 98765 43210"></label><label class="field"><span>City *</span><input name="city" required maxlength="100" value="<?= e($city) ?>" placeholder="e.g. Chennai"></label></div>
<label class="field"><span>Hospital / medical facility *</span><input name="hospital" required maxlength="150" value="<?= e($hospital) ?>" placeholder="Hospital name"></label>
<label class="field"><span>Urgency *</span><select name="urgency"><?php foreach($urgencies as $u): ?><option value="<?= e($u) ?>" <?= $urgency===$u?'selected':'' ?>><?= e($u) ?></option><?php endforeach; ?></select></label>
<button class="btn btn-red btn-wide" type="submit">Submit blood request <span>→</span></button><p class="privacy-note form-privacy">This student demo records requests only. It does not verify stock, reserve blood, or contact donors automatically.</p></form></main>
<footer><a class="brand footer-brand" href="index.php"><span class="brand-mark">♥</span><span>Life<span class="brand-red">Link</span><small> BLOOD CONNECT</small></span></a><p>Give blood. Give hope.</p><span>© <?= date('Y') ?> LifeLink · Student project</span></footer></body></html>
