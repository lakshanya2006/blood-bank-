LIFELINK — BLOOD BANK AVAILABILITY BETWEEN DONORS AND ACCEPTORS
Stack: PHP + MySQL (XAMPP) + HTML/CSS. Designed to run locally in Apache.

REQUIREMENTS
- Windows with XAMPP installed
- VS Code
- Apache and MySQL running in XAMPP Control Panel

INSTALL
1. Extract the folder "blood_bank_availability".
2. Copy the entire folder to: C:\xampp\htdocs\
   Final path should be C:\xampp\htdocs\blood_bank_availability\
3. Open XAMPP Control Panel and Start Apache and MySQL.
4. Open http://localhost/phpmyadmin/
5. Click Import -> Choose File -> select database.sql from this project folder -> click Import.
   The script creates database blood_bank_db and its tables.
6. Open VS Code -> File -> Open Folder -> C:\xampp\htdocs\blood_bank_availability
7. Open this URL in your browser:
   http://localhost/blood_bank_availability/
   Do NOT use the VS Code "Run PHP" button or Live Server for PHP.
8. Test:
   - Click Become a Donor and register a test donor.
   - Return to dashboard; the donor should appear.
   - Search by blood group or city.
   - Click Request Blood and submit a test request.
   - Recent request should appear on the dashboard.

DATABASE CONFIGURATION
config.php uses:
Host: localhost
Username: root
Password: (blank, default XAMPP setup)
Database: blood_bank_db
If your MySQL root account has a password, update $password in config.php.

TROUBLESHOOTING
- "Database connection failed": ensure MySQL is started and database.sql was imported.
- "Not Found": confirm the folder is inside C:\xampp\htdocs\blood_bank_availability and the URL matches.
- "spawn php ENOENT": do not use a VS Code PHP runner. Use the Apache URL above.
- CSS missing: verify style.css is directly in the project folder next to index.php.
- Port conflict: if Apache uses a port other than 80, use http://localhost:PORT/blood_bank_availability/ with the actual port.

IMPORTANT LIMITATIONS
This is a college demonstration project. It records donor details and blood requests but does not verify real blood inventory, donor medical eligibility, or actual blood availability. It does not send SMS/email or automatically reserve blood. In real emergencies, contact a licensed blood bank or hospital immediately. Use dummy contact details for public demos and do not publish personal donor data without explicit consent.
